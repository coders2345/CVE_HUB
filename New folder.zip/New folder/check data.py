import requests
from pymongo import MongoClient
# MongoDB setup
client = MongoClient("mongodb://localhost:27017/")
db = client["Mabasha"]  # Database name: "cve_database"
vulnerabilities_collection = db["Vulnerabilities"]  # Collection name: "Vulnerabilities"

# Function to store data in the database
def store_cve_data(cve_data):
    if cve_data:
        vulnerabilities = cve_data.get("vulnerabilities", [])
        if vulnerabilities:
            try:
                vulnerabilities_collection.insert_many(vulnerabilities)  # Insert data into collection
                print(f"Stored {len(vulnerabilities)} records in the 'Vulnerabilities' collection.")
            except Exception as e:
                print(f"Error storing data in the database: {e}")

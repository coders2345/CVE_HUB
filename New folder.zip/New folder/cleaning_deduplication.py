from pymongo import MongoClient

# MongoDB setup
client = MongoClient("mongodb://localhost:27017/")
db = client["Mabasha"]  # Using the "Mabasha" database
vulnerabilities_collection = db["Vulnerabilities"]

# Function to clean and deduplicate data
def clean_and_deduplicate_data():
    # Step 1: De-duplicate the data based on CVE ID
    duplicates_pipeline = [
        {"$group": {"_id": "$cve.id", "count": {"$sum": 1}}},
        {"$match": {"count": {"$gt": 1}}}
    ]
    duplicate_ids = [doc["_id"] for doc in vulnerabilities_collection.aggregate(duplicates_pipeline)]
    if duplicate_ids:
        print(f"Found {len(duplicate_ids)} duplicate records. Removing duplicates...")
        for _id in duplicate_ids:
            # Keep the first occurrence and remove the duplicates
            first_occurrence = vulnerabilities_collection.find_one({"cve.id": _id})
            vulnerabilities_collection.delete_many({"cve.id": _id})
            vulnerabilities_collection.insert_one(first_occurrence)
        print("Duplicates removed.")
    else:
        print("No duplicate records found.")

    # Step 2: Ensure data quality
    # Check for the presence of required fields
    required_fields = ["_id", "cve.id", "cve.published", "cve.lastModified", "cve.descriptions"]
    missing_data_count = 0
    for doc in vulnerabilities_collection.find():
        for field in required_fields:
            if field not in doc["cve"]:
                print(f"Missing required field '{field}' in document with CVE ID: {doc['cve']['id']}")
                missing_data_count += 1
                break
    if missing_data_count == 0:
        print("Data quality check passed. All documents have required fields.")
    else:
        print(f"Data quality check failed. Found {missing_data_count} documents with missing required fields.")

# Execute the clean and deduplicate function
clean_and_deduplicate_data()

# Get the total count of records in the collection after cleaning and deduplication
total_records_after_cleaning = vulnerabilities_collection.count_documents({})

# Print the total count of records after cleaning and deduplication
print(f"Total records in the 'Vulnerabilities' collection of the 'Mabasha' database after cleaning and deduplication: {total_records_after_cleaning}")

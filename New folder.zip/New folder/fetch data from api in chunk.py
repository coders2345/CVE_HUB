from pymongo import MongoClient

# Connection URI
uri = 'mongodb://localhost:27017'

# Database and collection names
db_name = 'Mabasha'
collection_name = 'Vulnerabilities'

# Connect to MongoDB
client = MongoClient(uri)
db = client[db_name]
collection = db[collection_name]

# Step 1: Identify duplicates
pipeline = [
    {
        '$group': {
            '_id': {'id': '$cve.id'},  # Group by CVE ID
            'count': {'$sum': 1},  # Count the occurrences of each group
            'ids': {'$push': '$_id'}  # Store the _id values of documents in each group
        }
    },
    {
        '$match': {
            'count': {'$gt': 1}  # Filter groups with more than one occurrence (duplicates)
        }
    },
    {
        '$project': {
            'ids': {'$slice': ['$ids', 1, {'$size': '$ids'}]}  # Keep only the first _id in each group
        }
    },
    {
        '$unwind': '$ids'  # Flatten the array of _ids
    },
    {
        '$group': {
            '_id': None,
            'ids': {'$push': '$ids'}  # Store the _ids of documents to remove
        }
    }
]

duplicate_ids = list(collection.aggregate(pipeline))

# Step 2: Remove duplicates from the collection
if duplicate_ids:
    ids_to_remove = duplicate_ids[0]['ids']
    result = collection.delete_many({'_id': {'$in': ids_to_remove}})
    print(f"Removed {result.deleted_count} duplicate documents from the collection.")
else:
    print("No duplicates found in the collection.")

# Close the MongoDB connection
client.close()

from flask import Flask, render_template, request
from pymongo import MongoClient

# Initialize Flask app
app = Flask(__name__)
# MongoDB connection configuration
MONGO_URI = 'mongodb://localhost:27017/'
DB_NAME = 'Mabasha'
COLLECTION_NAME = 'Vulnerabilities'
PER_PAGE = 10  # Number of items per page

# Function to fetch data from MongoDB with pagination
def get_data_from_mongodb(page):
    client = MongoClient(MONGO_URI)
    db = client[DB_NAME]
    collection = db[COLLECTION_NAME]
    skip = (page - 1) * PER_PAGE
    data = list(collection.find({}).skip(skip).limit(PER_PAGE))  # Fetch data for the current page
    client.close()
    return data

# Route to render HTML Template with MongoDB data
@app.route('/')
def index():
    page = request.args.get('page', default=1, type=int)
    total_docs = get_total_documents_count()
    total_pages = (total_docs + PER_PAGE - 1) // PER_PAGE
    data = get_data_from_mongodb(page)
    return render_template('index.html', data=data, page=page, total_pages=total_pages)

# Function to get the total number of documents in the collection
def get_total_documents_count():
    client = MongoClient(MONGO_URI)
    db = client[DB_NAME]
    collection = db[COLLECTION_NAME]
    total_docs = collection.count_documents({})
    client.close()
    return total_docs

if __name__ == '__main__':
    app.run(debug=True)

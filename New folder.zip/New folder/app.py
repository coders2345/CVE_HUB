from flask import Flask, jsonify
from flask_cors import CORS
from pymongo import MongoClient

app = Flask(__name__)
CORS(app)  # Enable CORS for all origins

# MongoDB connection configuration
mongo_client = MongoClient("mongodb://localhost:27017/")
db = mongo_client["Mabasha"]  # Replace "your_database_name" with your actual database name
collection = db["Vulnerabilities"]  # Replace "your_collection_name" with your actual collection name

# API route to fetch CVE data from MongoDB
@app.route("/api/cve")
def get_cve_data():
    # Retrieve data from MongoDB collection
    cve_data = list(collection.find({}, {"_id": 0}))  # Exclude "_id" field from the response
    return jsonify({"vulnerabilities": cve_data})


if __name__ == "__main__":
    app.run(debug=True)
